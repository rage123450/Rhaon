#include "TRContentsHandler.h"
//


#ifdef _QUIZ_QUIZ_
void CTRContentsHandler::OnRecv_QuizQuizStartAck(int iUseItemNum, int iPlayCount)
{
	if(!m_pQuizQuiz)
	{
		m_pQuizQuiz = move(static_cast<unique_ptr<CTRMiniGameQuizQuiz>>(GetPtr<CTRMiniGameQuizQuiz*>()));
	}
	m_pQuizQuiz->OnRecv_QuizQuizStartAck(iUseItemNum, iPlayCount);
}

void CTRContentsHandler::OnRecv_QuizQuizQuestionAck(int iIndexNum, int iQuestionNum)
{
	if(!m_pQuizQuiz)
	{
		m_pQuizQuiz = move(static_cast<unique_ptr<CTRMiniGameQuizQuiz>>(GetPtr<CTRMiniGameQuizQuiz*>()));
	}
	m_pQuizQuiz->OnRecv_QuizQuizQuestionAck(iIndexNum, iQuestionNum);
}

void CTRContentsHandler::OnRecv_QuizQuizAnswerAck(eServerResult eResult)
{
	if(!m_pQuizQuiz)
	{
		m_pQuizQuiz = move(static_cast<unique_ptr<CTRMiniGameQuizQuiz>>(GetPtr<CTRMiniGameQuizQuiz*>()));
	}
	m_pQuizQuiz->OnRecv_QuizQuizAnswerAck(eResult);
}

void CTRContentsHandler::OnRecv_QuizQuizIncorrectAnswerAck(const std::string & strCorrectAnswer)
{
	if(!m_pQuizQuiz)
	{
		m_pQuizQuiz = move(static_cast<unique_ptr<CTRMiniGameQuizQuiz>>(GetPtr<CTRMiniGameQuizQuiz*>()));
	}
	m_pQuizQuiz->OnRecv_QuizQuizIncorrectAnswerAck(strCorrectAnswer);
}

void CTRContentsHandler::OnRecv_QuizQuizRewardAck(int iRewardItemNum)
{
	if(!m_pQuizQuiz)
	{
		m_pQuizQuiz = move(static_cast<unique_ptr<CTRMiniGameQuizQuiz>>(GetPtr<CTRMiniGameQuizQuiz*>()));
	}
	m_pQuizQuiz->OnRecv_QuizQuizRewardAck(iRewardItemNum);
}

void CTRContentsHandler::OnRecv_QuizQuizFailedAck(eServerResult eResult)
{
	if(!m_pQuizQuiz)
	{
		m_pQuizQuiz = move(static_cast<unique_ptr<CTRMiniGameQuizQuiz>>(GetPtr<CTRMiniGameQuizQuiz*>()));
	}
	m_pQuizQuiz->OnRecv_QuizQuizFailedAck(eResult);
}
void CTRContentsHandler::showQuizQuizDlg()
{
	if(!m_pQuizQuiz)
	{
		m_pQuizQuiz = move(static_cast<unique_ptr<CTRMiniGameQuizQuiz>>(GetPtr<CTRMiniGameQuizQuiz*>()));
	}
	m_pQuizQuiz->showDialog();
}
#endif // _QUIZ_QUIZ



#ifdef _TETRIS_
void CTRContentsHandler::OnRecv_TetrisStartAck(int iUseItemNum, int iPlayCount)
{
	if(!m_pTetris)
	{
		m_pTetris = move(static_cast<unique_ptr<CTRMiniGameTetris>>(GetPtr<CTRMiniGameTetris*>()));
	}
	m_pTetris->OnRecv_TetrisStartAck(iUseItemNum, iPlayCount);
}

void CTRContentsHandler::OnRecv_TetrisQuestionAck(int iIndexNum, int iQuestionNum)
{
	if(!m_pTetris)
	{
		m_pTetris = move(static_cast<unique_ptr<CTRMiniGameTetris>>(GetPtr<CTRMiniGameTetris*>()));
	}
	m_pTetris->OnRecv_TetrisQuestionAck(iIndexNum, iQuestionNum);
}

void CTRContentsHandler::OnRecv_TetrisAnswerAck(eServerResult eResult)
{
	if(!m_pTetris)
	{
		m_pTetris = move(static_cast<unique_ptr<CTRMiniGameTetris>>(GetPtr<CTRMiniGameTetris*>()));
	}
	m_pTetris->OnRecv_TetrisAnswerAck(eResult);
}

void CTRContentsHandler::OnRecv_TetrisIncorrectAnswerAck(const std::string & strCorrectAnswer)
{
	if(!m_pTetris)
	{
		m_pTetris = move(static_cast<unique_ptr<CTRMiniGameTetris>>(GetPtr<CTRMiniGameTetris*>()));
	}
	m_pTetris->OnRecv_TetrisIncorrectAnswerAck(strCorrectAnswer);
}

void CTRContentsHandler::OnRecv_TetrisRewardAck(int iRewardItemNum)
{
	if(!m_pTetris)
	{
		m_pTetris = move(static_cast<unique_ptr<CTRMiniGameTetris>>(GetPtr<CTRMiniGameTetris*>()));
	}
	m_pTetris->OnRecv_TetrisRewardAck(iRewardItemNum);
}

void CTRContentsHandler::OnRecv_TetrisFailedAck(eServerResult eResult)
{
	if(!m_pTetris)
	{
		m_pTetris = move(static_cast<unique_ptr<CTRMiniGameTetris>>(GetPtr<CTRMiniGameTetris*>()));
	}
	m_pTetris->OnRecv_TetrisFailedAck(eResult);
}
void CTRContentsHandler::showTetrisDlg()
{
	if(!m_pTetris)
	{
		m_pTetris = move(static_cast<unique_ptr<CTRMiniGameTetris>>(GetPtr<CTRMiniGameTetris*>()));
	}
	m_pTetris->showDialog();
}
#endif // _TETRIS_