#pragma once
#include "main.h"
#include "TRMiniGameQuizQuiz.h"
#include "TRMiniGameTetris.h"

class CTRContentsHandler
{
private:
	unique_ptr<CTRMiniGameQuizQuiz> m_pQuizQuiz;
	unique_ptr<CTRMiniGameTetris> m_pTetris;

public:
	CTRContentsHandler() = default;
	~CTRContentsHandler() = default;

#ifdef _QUIZ_QUIZ_
public:
	void OnRecv_QuizQuizStartAck(int iUseItemNum, int iPlayCount);
	void OnRecv_QuizQuizQuestionAck(int iIndexNum, int iQuestionNum);
	void OnRecv_QuizQuizAnswerAck(eServerResult eResult);
	void OnRecv_QuizQuizIncorrectAnswerAck(const std::string &strCorrectAnswer);
	void OnRecv_QuizQuizRewardAck(int iRewardItemNum);
	void OnRecv_QuizQuizFailedAck(eServerResult eResult);
	void showQuizQuizDlg();
#endif // _QUIZ_QUIZ_

#ifdef _TETRIS_
public:
	void OnRecv_TetrisStartAck(int iUseItemNum, int iPlayCount);
	void OnRecv_TetrisQuestionAck(int iIndexNum, int iQuestionNum);
	void OnRecv_TetrisAnswerAck(eServerResult eResult);
	void OnRecv_TetrisIncorrectAnswerAck(const std::string &strCorrectAnswer);
	void OnRecv_TetrisRewardAck(int iRewardItemNum);
	void OnRecv_TetrisFailedAck(eServerResult eResult);
	void showTetrisDlg();
#endif // _TETRIS_

private:
	template<typename T>
	T GetPtr()
	{
		const type_info& info = typeid(T);

		if(typeid(CTRMiniGameQuizQuiz*) == info)
		{
			return dynamic_cast<T>(new CTRMiniGameQuizQuiz());
		}
		else if(typeid(CTRMiniGameTetris*) == info)
		{
			return dynamic_cast<T>(new CTRMiniGameTetris());
		}
		else
		{
			return nullptr;
		}
	}
};

