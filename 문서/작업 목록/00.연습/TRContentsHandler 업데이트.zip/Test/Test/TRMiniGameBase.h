#pragma once
#include "main.h"
class CTRMiniGameBase
{
public:
	CTRMiniGameBase() = default;
	virtual ~CTRMiniGameBase() = default;

public:
	virtual void showDialog() = 0;
};

