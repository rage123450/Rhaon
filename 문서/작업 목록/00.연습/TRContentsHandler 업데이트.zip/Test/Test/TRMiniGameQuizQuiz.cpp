#include "TRMiniGameQuizQuiz.h"

void CTRMiniGameQuizQuiz::showDialog()
{
	cout << "The content of the QuizQuiz comes out." << endl;
}

void CTRMiniGameQuizQuiz::OnRecv_QuizQuizStartAck(int iUseItemNum, int iPlayCount)
{
}

void CTRMiniGameQuizQuiz::OnRecv_QuizQuizQuestionAck(int iIndexNum, int iQuestionNum)
{
}

void CTRMiniGameQuizQuiz::OnRecv_QuizQuizAnswerAck(eServerResult eResult)
{
}

void CTRMiniGameQuizQuiz::OnRecv_QuizQuizIncorrectAnswerAck(const std::string & strCorrectAnswer)
{
}

void CTRMiniGameQuizQuiz::OnRecv_QuizQuizRewardAck(int iRewardItemNum)
{
}

void CTRMiniGameQuizQuiz::OnRecv_QuizQuizFailedAck(eServerResult eResult)
{
}