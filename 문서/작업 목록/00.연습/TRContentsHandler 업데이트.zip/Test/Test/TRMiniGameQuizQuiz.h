#pragma once
#include "main.h"
#include "TRMiniGameBase.h"
class CTRMiniGameQuizQuiz :
	public CTRMiniGameBase
{
public:
	CTRMiniGameQuizQuiz() = default;
	virtual ~CTRMiniGameQuizQuiz() = default;

public:
	// CTRMiniGameBase��(��) ���� ��ӵ�
	virtual void showDialog() override;

public:
	void OnRecv_QuizQuizStartAck(int iUseItemNum, int iPlayCount);
	void OnRecv_QuizQuizQuestionAck(int iIndexNum, int iQuestionNum);
	void OnRecv_QuizQuizAnswerAck(eServerResult eResult);
	void OnRecv_QuizQuizIncorrectAnswerAck(const std::string &strCorrectAnswer);
	void OnRecv_QuizQuizRewardAck(int iRewardItemNum);
	void OnRecv_QuizQuizFailedAck(eServerResult eResult);
};

