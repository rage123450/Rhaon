#include "TRMiniGameTetris.h"

void CTRMiniGameTetris::showDialog()
{
	cout << "The content of the Tetris comes out." << endl;
}

void CTRMiniGameTetris::OnRecv_TetrisStartAck(int iUseItemNum, int iPlayCount)
{
}

void CTRMiniGameTetris::OnRecv_TetrisQuestionAck(int iIndexNum, int iQuestionNum)
{
}

void CTRMiniGameTetris::OnRecv_TetrisAnswerAck(eServerResult eResult)
{
}

void CTRMiniGameTetris::OnRecv_TetrisIncorrectAnswerAck(const std::string & strCorrectAnswer)
{
}

void CTRMiniGameTetris::OnRecv_TetrisRewardAck(int iRewardItemNum)
{
}

void CTRMiniGameTetris::OnRecv_TetrisFailedAck(eServerResult eResult)
{
}
