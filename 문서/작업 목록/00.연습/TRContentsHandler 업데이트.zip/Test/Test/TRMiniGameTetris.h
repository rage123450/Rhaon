#pragma once
#include "main.h"
#include "TRMiniGameBase.h"
class CTRMiniGameTetris :
	public CTRMiniGameBase
{
public:
	CTRMiniGameTetris() = default;
	virtual ~CTRMiniGameTetris() = default;

public:
	// CTRMiniGameBase��(��) ���� ��ӵ�
	virtual void showDialog() override;

public:
	void OnRecv_TetrisStartAck(int iUseItemNum, int iPlayCount);
	void OnRecv_TetrisQuestionAck(int iIndexNum, int iQuestionNum);
	void OnRecv_TetrisAnswerAck(eServerResult eResult);
	void OnRecv_TetrisIncorrectAnswerAck(const std::string &strCorrectAnswer);
	void OnRecv_TetrisRewardAck(int iRewardItemNum);
	void OnRecv_TetrisFailedAck(eServerResult eResult);
};

