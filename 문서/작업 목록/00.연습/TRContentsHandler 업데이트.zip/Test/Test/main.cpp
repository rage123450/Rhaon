﻿#include "main.h"
#include "TRContentsHandler.h"

int main()
{
	unique_ptr<CTRContentsHandler> m_pHandler = make_unique<CTRContentsHandler>();
	m_pHandler->showQuizQuizDlg();
	m_pHandler->showTetrisDlg();

	return 0;
}