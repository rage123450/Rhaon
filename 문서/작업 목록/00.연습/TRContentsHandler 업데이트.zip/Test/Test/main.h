#pragma once
#include <iostream>
#include <fstream>
#include <sstream>
#include <memory>
#include <algorithm>
#include <functional>

#include <deque>
#include <string>
#include <list>
#include <forward_list>
#include <vector>
#include <map>
#include <unordered_map>

using namespace std;

enum eServerResult{};

#ifndef _QUIZ_QUIZ_
#define _QUIZ_QUIZ_
#endif // !_QUIZ_QUIZ_

#ifndef _TETRIS_
#define _TETRIS_
#endif // !_TETRIS_


